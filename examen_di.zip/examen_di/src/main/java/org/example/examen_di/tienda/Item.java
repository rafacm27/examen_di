package com.tienda.model;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "items")
@Data
public class Item {
    @Id
    private String id;
    private int internalId;
    private String title;
    private double price;
    private String category;
    private String description;
    private double rate;
    private int count;
    private String image;
}
